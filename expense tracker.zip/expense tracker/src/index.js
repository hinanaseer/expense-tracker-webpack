import './style.css';

const expenses = [];

function addExpense(description, amount) {
  expenses.push({ description, amount });
}

function displayExpenses() {
  const expenseList = document.querySelector('#expense-list');
  expenseList.innerHTML = '';
  expenses.forEach((expense) => {
    const listItem = document.createElement('li');
    listItem.innerText = `${expense.description}: $${expense.amount}`;
    expenseList.appendChild(listItem);
  });
}

const form = document.querySelector('#expense-form');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const description = event.target.elements.description.value;
  const amount = event.target.elements.amount.value;
  addExpense(description, amount);
  displayExpenses();
  event.target.reset();
});
